<?php

try{
    $pdo=new PDO('mysql:host=localhost;dbname=u448536604_facturacion','u448536604_administrador','Administrador1');
    // echo "Conexión Exitosa!!!";
}catch(PDOException $e){
    print "ERROR".$e->getMessage()."<br>";
    die();
}







?>