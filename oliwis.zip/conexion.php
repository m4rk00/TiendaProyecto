<?php 

    $host = 'localhost';
    $user = 'u448536604_administrador';
    $password = 'Administrador1';
    $db = 'u448536604_facturacion';

    $conection = @mysqli_connect($host,$user,$password,$db);

    if(!$conection){
        echo "Error en la conexión";
    }

?>