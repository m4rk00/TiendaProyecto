window.onload = function() {
    /**/
    $('#preloader').fadeOut();
}